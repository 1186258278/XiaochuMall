<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="Content-Language" content="zh-cn"/>
    <meta name="renderer" content="webkit"/>
    <title>购买<?= $Pay['name'] ?></title>
    <link href="/includes/lib/soft/controller/officeCodePayment/assets/css/alipay_pay.css?i=1" rel="stylesheet"
          media="screen"/>
    <meta name="keywords" content="<?= $conf['keywords'] ?>">
    <meta name="description" content="<?= $conf['description'] ?>">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
</head>
<body>
<div class="body">
    <h1 class="mod-title"><span class="text"><?= $Pay['type'] ?>在线支付</span></h1>
    <div class="mod-ct">
        <div class="order">
        </div>
        <div class="amount" style="margin-top: 0;color: #386cfa">
            ￥<?= round($Pay['money'], 2) ?>
        </div>
        <div class="qr-image" style="margin-top: 10px;">
            <img style="width: 200px;height: 200px;"
                 src="//pay.79tian.com/qrcode.php?text=<?= $Pay['qrcode'] ?>"/>
        </div>
        <div style="margin-top: 1em" id="Start">
            <a href="<?= $Pay['h5_qrurl'] ?>" target="_blank" class="header__order">启动<?= $Pay['type'] ?></a>
        </div>
        <div style="margin-top: 1em;color: red;font-weight: 500">
            <div style="font-size: 1.2em">请付款 <?= round($Pay['money'], 2) ?> 元,注意不能多付或少付</div>
            <div id="divTime"></div>
        </div>
        <div style="margin-top: 1em;">
            <?= $Pay['console_notity'] ?>
        </div>
        <div class="detail detail-open" style="margin-top: 10px;" id="orderDetail">
            <dl class="detail-ct">
                <dt>
                    购买物品
                </dt>
                <dd id="productName">
                    <?= $Pay['name'] ?>
                </dd>
                <dt>
                    商户订单号
                </dt>
                <dd id="billId">
                    <?= $Pay['order'] ?>
                </dd>
                <dt>
                    创建时间
                </dt>
                <dd id="createTime">
                    <?= $Pay['addtime'] ?>
                </dd>
            </dl>
            <br>
            <a href="javascript:qralipay.OrderLog()" class="arrow"><i class="ico-arrow"></i></a>
        </div>
        <div class="tip">
            <div class="ico-scan"></div>
            <div class="tip-text">
                <p>请使用<?= $Pay['type'] ?>扫一扫</p>
                <p>扫描二维码完成支付</p>
            </div>
        </div>
        <div class="tip-text">
        </div>
    </div>
</div>
<script src="<?= ROOT_DIR ?>assets/js/jquery-3.4.1.min.js"></script>
<script>
    var intDiff = parseInt('<?=$Pay['timeout_time']?>');//倒计时总秒数量
    function timer(intDiff) {
        window.setInterval(function () {
            var day = 0,
                hour = 0,
                minute = 0,
                second = 0;//时间默认值
            if (intDiff > 0) {
                day = Math.floor(intDiff / (60 * 60 * 24));
                hour = Math.floor(intDiff / (60 * 60)) - (day * 24);
                minute = Math.floor(intDiff / 60) - (day * 24 * 60) - (hour * 60);
                second = Math.floor(intDiff) - (day * 24 * 60 * 60) - (hour * 60 * 60) - (minute * 60);
            }
            if (minute <= 9) minute = '0' + minute;
            if (second <= 9) second = '0' + second;
            if (hour <= 0 && minute <= 0 && second <= 0) {
                location.reload();
                $("#divTime").html("<small style='color:red; font-size:26px'>订单二维码已过期</small>");
            } else {
                $("#divTime").html("二维码有效时间:<small style='color:red; font-size:26px'>" + minute + "</small>分<small style='color:red; font-size:26px'>" + second + "</small>秒,失效勿付");
            }
            intDiff--
        }, 1000);
    }

    $(function () {
        timer(intDiff);
    });

    var qralipay = {
        OrderLog: function () { //查看订单详情
            if ($('#orderDetail').hasClass('detail-open')) {
                $('#orderDetail .detail-ct').slideUp(500, function () {
                    $('#orderDetail').removeClass('detail-open');
                });
            } else {
                $('#orderDetail .detail-ct').slideDown(500, function () {
                    $('#orderDetail').addClass('detail-open');
                });
            }
        },
        OrderMonitor: function (time = 3000) { //订单监控 3s 1轮询
            $.ajax({
                type: "POST",
                dataType: "json",
                url: "<?=ROOT_DIR?>ajax.php?act=OrderState",
                timeout: 10000, //ajax请求超时时间10s
                data: {
                    order: "<?php echo $Pay['order']?>",
                    type: 2
                },
                success: function (data) {
                    //从服务器得到数据，显示数据并继续查询
                    if (data.code == 1) {
                        if (confirm("您已支付完成，需要跳转到订单页面吗？")) {
                            switch (<?=$Pay['gid']?>) {
                                case -1:
                                    window.location.href = '<?=ROOT_DIR?>?mod=route&p=User';
                                    break;
                                case -3:
                                    window.location.href = '<?=ROOT_DIR?>HostAdmin';
                                    break;
                                default:
                                    window.location.href = '<?=ROOT_DIR?>?mod=route&p=Order';
                                    break;
                            }
                        } else {
                            // 用户取消
                        }
                    } else {
                        setTimeout(function () {
                            qralipay.OrderMonitor();
                        }, time);
                    }
                },
                //Ajax请求超时，继续查询
                error: function (XMLHttpRequest, textStatus) {
                    if (textStatus == "timeout") {
                        setTimeout(function () {
                            qralipay.OrderMonitor();
                        }, 1000);
                    } else { //异常
                        setTimeout(function () {
                            qralipay.OrderMonitor();
                        }, time);
                    }
                }
            });
        },
    };
    setTimeout(function () {
        qralipay.OrderMonitor();
    }, 3000);

    /**
     * 检验是否手机版，手机版直接跳转到APP支付
     * @returns
     */
    function isMobilCheck() {
        var userAgentInfo = navigator.userAgent;
        var Agents = new Array("Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod");
        var flag = true;
        for (var v = 0; v < Agents.length; v++) {
            if (userAgentInfo.indexOf(Agents[v]) > 0) {
                flag = false;
                break;
            }
        }
        return flag;
    }

    if (isMobilCheck()) {
        $("#Start").hide();
    }
</script>
</body>
</html>